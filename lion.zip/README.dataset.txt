# lion1 > 2025-12-05 3:21pm
https://universe.roboflow.com/pavan-cjqba/lion1-wq6rq

Provided by a Roboflow user
License: CC BY 4.0


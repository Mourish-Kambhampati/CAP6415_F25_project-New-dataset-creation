# tiger1 > 2025-12-05 3:19pm
https://universe.roboflow.com/pavan-cjqba/tiger1-nusp5

Provided by a Roboflow user
License: CC BY 4.0

